#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <limits.h>

/* RAW files contain signed microseconds: positive high, negative low.
 * Merge adjacent equal levels and reject unrepresentable durations. */
static inline bool
    finder_raw_append(int32_t* raw, size_t* count, size_t capacity, bool level, uint32_t duration) {
    if(!duration) return true;
    if(duration > INT32_MAX) return false;
    int32_t sample = level ? (int32_t)duration : -(int32_t)duration;
    if(*count && ((raw[*count - 1] > 0) == level)) {
        int64_t merged = (int64_t)raw[*count - 1] + sample;
        if(merged > INT32_MAX || merged < -INT32_MAX) return false;
        raw[*count - 1] = (int32_t)merged;
        return true;
    }
    if(*count >= capacity) return false;
    raw[(*count)++] = sample;
    return true;
}

/* Continuous RGB hue wheel, at half brightness. */
static inline uint32_t finder_led_rgb(uint16_t phase) {
    phase %= 1536;
    uint8_t part = phase % 256;
    uint8_t r = 0, g = 0, b = 0;
    switch(phase / 256) {
    case 0:
        r = 255;
        g = part;
        break;
    case 1:
        r = 255 - part;
        g = 255;
        break;
    case 2:
        g = 255;
        b = part;
        break;
    case 3:
        g = 255 - part;
        b = 255;
        break;
    case 4:
        r = part;
        b = 255;
        break;
    default:
        r = 255;
        b = 255 - part;
        break;
    }
    return ((uint32_t)(r / 2) << 16) | ((uint32_t)(g / 2) << 8) | (b / 2);
}

/* Sweep the three CC1101 receive bands without crossing unsupported gaps.
 * 250 kHz spacing overlaps the 650 kHz receive preset. */
static inline uint32_t finder_next_frequency(uint32_t hz) {
    if(hz < 348000000) return hz + 250000;
    if(hz < 387000000) return 387000000;
    if(hz < 464000000) return hz + 250000;
    if(hz < 779000000) return 779000000;
    if(hz < 928000000) return hz + 250000;
    return 300000000;
}

static inline uint32_t finder_step_frequency(uint32_t hz, int32_t step) {
    int64_t next = (int64_t)hz + step;
    if(step > 0) {
        if(next > 928000000) return 300000000;
        if(next > 348000000 && next < 387000000) return 387000000;
        if(next > 464000000 && next < 779000000) return 779000000;
    } else {
        if(next < 300000000) return 928000000;
        if(next > 348000000 && next < 387000000) return 348000000;
        if(next > 464000000 && next < 779000000) return 464000000;
    }
    return (uint32_t)next;
}

static inline uint32_t finder_beep_interval(int rssi, int threshold) {
    if(rssi < threshold) return 0;
    int strength = rssi - threshold;
    int span = -30 - threshold;
    if(strength > span) strength = span;
    return 900 - (uint32_t)(strength * 800 / span);
}

static inline uint8_t finder_graph_height(int rssi) {
    if(rssi < -110) rssi = -110;
    if(rssi > -30) rssi = -30;
    return (uint8_t)((rssi + 110) * 22 / 80);
}

static inline uint32_t finder_quick_frequency(uint32_t hz, int direction) {
    const uint32_t common[] = {
        300000000, 315000000, 390000000, 433920000, 868350000, 915000000, 925000000};
    if(direction > 0) {
        for(unsigned i = 0; i < sizeof(common) / sizeof(common[0]); i++) {
            if(common[i] > hz) return common[i];
        }
        return common[0];
    }
    for(int i = (int)(sizeof(common) / sizeof(common[0])) - 1; i >= 0; i--) {
        if(common[i] < hz) return common[i];
    }
    return common[sizeof(common) / sizeof(common[0]) - 1];
}
