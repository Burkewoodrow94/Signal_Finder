# SubGHz Signal Finder 1.4

Receive-only Flipper Zero app for the built-in CC1101: signal sweep, RSSI graph
and beeps, RAW saving, protocol decoding in LOCK, and a rainbow scanning LED.
Includes the custom locator/signal icon and the corrected standard radio bands:
300-348, 387-464 and 779-928 MHz.

## Install

Copy `dist/signal_finder_v1_4.fap` with qFlipper to **SD Card/apps/Sub-GHz/**.
Remove older copies, then open **Apps > Sub-GHz > SubGHz Signal Finder**.
No firmware flashing is required. `dist/signal_finder.fap` is the same build.

Target: hardware 7, API 88.9. All 91 imports were checked against Unleashed API
88.15 at commit `7c1b4fff4ba9f5873c9c2cb75f76e080da699272`. This checks exported
API declarations; exact device firmware identity and runtime behavior remain
subject to on-device validation.

## Controls

| Button | Action |
| --- | --- |
| OK during sweep | Lock the detected peak |
| OK in LOCK | Open/close decoded details |
| Up/down in details | Scroll decoded data and fields |
| Long Back in LOCK | Return to sweep |
| Short Back in details | Return to graph |
| Short Back on graph/sweep | Exit |
| Left/right | During sweep, lock at 433.920 MHz; in LOCK, tune by 25 kHz |
| Long left/right | Jump to the previous/next common frequency |
| Up/down on graph/sweep | Adjust detection/beep threshold |
| Long Up | Start RAW; hold again to stop and save |
| Short Back during RAW | Discard capture and return to LOCK |
| Long Down | Cycle OOK, FSK2 (2.38 kHz deviation), FSK12 (12.7 kHz deviation) |
| Long OK | Mute/unmute beeps |

Quick frequencies: 300, 315, 390, 433.920, 868.350, 915 and 925 MHz.
Tuning skips unsupported gaps; settings reset at launch.

## RAW saving

Hold Up from normal sweep to hold the detected peak and record it; with no peak,
it uses 433.920 MHz. In LOCK, it records the selected frequency. Activate your
transmitter while RAW is displayed. Hold Up again to save. Capture automatically
stops after **10 seconds or 4,096 signed pulse timings**, whichever comes first.
Noise may fill it sooner. Buffer-limited files include a comment noting the cut.

Files: **SD Card/subghz/signal_finder/SF_<timestamp>_<counter>.sub**
(`/ext/subghz/signal_finder/`). Existing files are not overwritten. The screen
reports the saved filename or SD error. Each standard Flipper RAW file contains
its frequency, receive preset, `Protocol: RAW`, and positive (high) / negative
(low) microsecond timings. Adjacent equal levels are merged. This app provides
no transmit function and does not save decoded-key files.

RAW holds one frequency and modulation: hopping channels would make the timing
file unusable. Retuning and mode changes are blocked while recording. Decoding
pauses during RAW; LOCK decoding resumes after saving/cancelling. Empty captures
are not saved. Queue overflow discards RAW with a warning rather than silently
saving missing pulses. An SD write/close error removes any newly created partial
file and releases the buffer; fix storage and record again.

## LOCK decoding

The graph shows the latest protocol name, or **Unknown protocol** until a
supported frame arrives. Press OK for the firmware decoder's complete text:
decoded key/data, bit count, serial, button, counter, manufacturer and other
fields when that decoder supplies them. Up/down scrolls; OK/Back returns to the
graph. Decoding continues in the details screen.

The latest frame persists until another arrives or you retune/change modulation;
it does not prove a transmitter is still active. OOK/FSK selection is manual.
The app uses firmware protocols marked decodable, excluding RAW/BinRAW pseudo-
protocols. Manufacturer key databases are not loaded, so some encrypted/rolling-
code fields may be unknown. It cannot decrypt arbitrary signals or guarantee
physical device identity. Decoding depends on frequency, modulation, signal
quality and the protocols included in your firmware.

## Scanning LED and signal strength

While sweeping, the LED cycles smoothly through **192 colour steps** around red,
yellow, green, cyan, blue and purple. It uses half-scale RGB values, respecting
firmware LED brightness settings, with updates about every 60 ms (one cycle
about 12 seconds plus processing overhead). LOCK, RAW and exit release the LED
notification override.

SWEEP visits 1,099 channels in 250 kHz steps, settling at least 8 ms per hop.
A sweep takes at least about nine seconds plus overhead. Frequency/RSSI is the
channel currently sampled; Peak is the strongest qualifying channel from the
recent completed/current sweep. Old peaks may persist for roughly two sweeps.
Changing modulation clears the peak and restarts the sweep.

LOCK's graph covers about five seconds at a fixed -110 to -30 dBm scale. Above
the adjustable threshold (default -85 dBm), 25 ms beeps speed up from about
900 ms to 100 ms spacing as RSSI strengthens. Sound is muted if speaker ownership
is unavailable. Noise and other transmitters can trigger detections or fill RAW.

Peaks are approximate receive channels, not exact carrier measurements. Fine-
tune in LOCK. Short bursts can be missed while sweeping. Silent devices and
signals outside the supported bands cannot be found. RSSI cannot reliably give
metres, direction or identity, or separate transmitters sharing a frequency.
Antenna orientation, shielding and reflections affect readings.

## Build and verification

With Python and uFBT installed, run `./build.ps1` in Windows PowerShell. It uses
the pinned Unleashed 093 SDK in project-local `.build-sdk/ufbt`, preserving the
existing SDK, and reuses the user-profile toolchain. Output:
`dist/signal_finder.fap`. The build script does not create versioned delivery
copies or source ZIPs.

`./build.ps1 -Validate` installs Unicorn 2.1.4 into ignored `.build-sdk/test-python`
and executes Cortex-M4 Thumb tests for all sweep frequencies and quantized
radio-path boundaries, tuning wrap, quick selection, beep timing, graph bounds,
RAW polarity/merging/buffer limits/duration overflow, and LED colour/brightness/
wrap. It checks final FAP imports against pinned API 88.15 and rejects transmit
or packet-write imports. `ufbt lint` checks formatting.

Interrupts only enqueue pulses; decoding and storage run in the app thread.
Capture memory is bounded. Async RX stops before tuning, saving or freeing
resources. Preset loading precedes tuning because it resets the CC1101. The
receiver omits unused RAW/BinRAW allocations. Dynamic LED messages use blocking
notification calls so their memory remains valid until consumed.

**Hardware checks remain required:** verify scan LED cycling and its release on
LOCK/exit; receive a known supported OOK frame and inspect/scroll its fields;
change modulation and confirm old fields clear; capture, save and inspect a RAW
file via qFlipper; test cancel, buffer-limit auto-save, missing SD and exit.
Confirm the built-in Sub-GHz app works afterward. Radio, protocol and SD workflow
checks have not been performed on the user's device here.

References: [SDK release](https://github.com/DarkFlippers/unleashed-firmware/releases/tag/unlshd-093),
[API 88.15](https://github.com/DarkFlippers/unleashed-firmware/blob/7c1b4fff4ba9f5873c9c2cb75f76e080da699272/targets/f7/api_symbols.csv),
[standard radio paths](https://github.com/flipperdevices/flipperzero-firmware/blob/dev/targets/f7/furi_hal/furi_hal_subghz.c),
[receiver](https://github.com/flipperdevices/flipperzero-firmware/blob/dev/lib/subghz/receiver.c).
