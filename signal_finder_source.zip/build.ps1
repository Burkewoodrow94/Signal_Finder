param([switch]$Validate)
$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
$previousUfbt = $env:UFBT_HOME
$previousToolchain = $env:FBT_TOOLCHAIN_PATH
try {
    $state = Join-Path $PSScriptRoot '.build-sdk'
    New-Item -ItemType Directory -Force $state | Out-Null
    $sdk = Join-Path $state 'unleashed-093.zip'
    if (!(Test-Path -LiteralPath $sdk)) {
        Invoke-WebRequest 'https://github.com/DarkFlippers/unleashed-firmware/releases/download/unlshd-093/flipper-z-f7-sdk-unlshd-093.zip' -OutFile $sdk
    }
    $env:UFBT_HOME = Join-Path $state 'ufbt'
    $env:FBT_TOOLCHAIN_PATH = Join-Path $env:USERPROFILE '.ufbt'
    if (!(Test-Path -LiteralPath (Join-Path $env:UFBT_HOME 'current/ufbt_state.json'))) {
        ufbt update --hw-target f7 --local $sdk
        if ($LASTEXITCODE -ne 0) { throw 'SDK deployment failed' }
    }
    ufbt
    if ($LASTEXITCODE -ne 0) { throw 'FAP build failed' }
    ufbt lint
    if ($LASTEXITCODE -ne 0) { throw 'Lint failed' }
    if ($Validate) {
        Invoke-WebRequest 'https://raw.githubusercontent.com/DarkFlippers/unleashed-firmware/7c1b4fff4ba9f5873c9c2cb75f76e080da699272/targets/f7/api_symbols.csv' -OutFile (Join-Path $state 'device-api.csv')
        python -m pip install --target (Join-Path $state 'test-python') unicorn==2.1.4
        if ($LASTEXITCODE -ne 0) { throw 'Test dependency installation failed' }
        python tests/validate.py
        if ($LASTEXITCODE -ne 0) { throw 'Validation failed' }
    }
} finally {
    $env:UFBT_HOME = $previousUfbt
    $env:FBT_TOOLCHAIN_PATH = $previousToolchain
    Pop-Location
}
