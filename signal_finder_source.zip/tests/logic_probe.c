#include "finder_logic.h"
uint32_t probe_led(uint32_t phase) {
    return finder_led_rgb((uint16_t)phase);
}
uint32_t probe_next(uint32_t hz) {
    return finder_next_frequency(hz);
}
uint32_t probe_step(uint32_t hz, int32_t step) {
    return finder_step_frequency(hz, step);
}
uint32_t probe_beep(int rssi, int threshold) {
    return finder_beep_interval(rssi, threshold);
}
uint32_t probe_graph(int rssi) {
    return finder_graph_height(rssi);
}
uint32_t probe_quick(uint32_t hz, int direction) {
    return finder_quick_frequency(hz, direction);
}

uint32_t probe_raw(unsigned scenario) {
    int32_t values[4] = {123, 456, 789, 999};
    size_t count = 0;
    if(scenario == 0) {
        if(!finder_raw_append(values, &count, 4, true, 100)) return 1;
        if(!finder_raw_append(values, &count, 4, true, 200)) return 2;
        if(!finder_raw_append(values, &count, 4, false, 400)) return 3;
        if(count != 2 || values[0] != 300 || values[1] != -400) return 4;
    } else if(scenario == 1) {
        finder_raw_append(values, &count, 2, true, 100);
        finder_raw_append(values, &count, 2, false, 200);
        if(finder_raw_append(values, &count, 2, true, 300)) return 1;
        if(count != 2 || values[2] != 789) return 2;
    } else if(scenario == 2) {
        if(!finder_raw_append(values, &count, 4, true, 0) || count) return 1;
        if(finder_raw_append(values, &count, 4, true, 0xffffffff)) return 2;
        if(count) return 3;
    } else {
        finder_raw_append(values, &count, 4, false, INT32_MAX);
        if(finder_raw_append(values, &count, 4, false, 1)) return 1;
        if(values[0] != -INT32_MAX || count != 1) return 2;
    }
    return 0;
}
