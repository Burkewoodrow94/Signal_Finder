"""Validate ARM-compiled tuning logic and the delivered FAP's firmware imports."""
import csv
import os
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".build-sdk/test-python"))
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS
from unicorn.arm_const import UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_SP, UC_ARM_REG_LR

toolchain = pathlib.Path.home() / ".ufbt/toolchain/x86_64-windows/bin"
os.environ["PATH"] = str(toolchain) + os.pathsep + os.environ["PATH"]
build = ROOT / ".build-sdk"

def run(tool, *args):
    return subprocess.check_output([str(toolchain / (tool + ".exe")), *map(str, args)], text=True)

run("arm-none-eabi-gcc", "-mcpu=cortex-m4", "-mthumb", "-Os", "-nostdlib",
    "-I", ROOT, "-Wl,-Ttext=0x10000", "-Wl,-e,probe_next",
    ROOT / "tests/logic_probe.c", "-o", build / "logic.elf")
run("arm-none-eabi-objcopy", "-O", "binary", build / "logic.elf", build / "logic.bin")
symbols = {}
for line in run("arm-none-eabi-nm", build / "logic.elf").splitlines():
    parts = line.split()
    if len(parts) == 3 and parts[2].startswith("probe_"):
        symbols[parts[2]] = int(parts[0], 16)

cpu = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
cpu.mem_map(0x10000, 0x10000)
cpu.mem_map(0x20000000, 0x10000)
cpu.mem_write(0x10000, (build / "logic.bin").read_bytes())

def call(name, a, b=0):
    cpu.reg_write(UC_ARM_REG_SP, 0x20008000)
    cpu.reg_write(UC_ARM_REG_LR, 0x18001)
    cpu.reg_write(UC_ARM_REG_R0, a & 0xffffffff)
    cpu.reg_write(UC_ARM_REG_R1, b & 0xffffffff)
    cpu.emu_start(symbols["probe_" + name] | 1, 0x18000, count=1000)
    return cpu.reg_read(UC_ARM_REG_R0)

def valid(hz):
    return any(lo <= hz <= hi for lo, hi in
               [(300000000, 348000000), (387000000, 464000000), (779000000, 928000000)])

def radio_path_valid(hz):
    # The HAL chooses a path using the synthesizer's quantized frequency.
    actual = (hz * 65536 // 26000000) * 26000000 // 65536
    return any(lo <= actual <= hi for lo, hi in
               [(299999755, 348000335), (386999938, 464000000), (778999847, 928000000)])

hz = 300000000
seen = set()
while hz not in seen:
    assert valid(hz), hz
    assert radio_path_valid(hz), hz
    seen.add(hz)
    for delta in [-25000, 25000]:
        assert valid(call("step", hz, delta))
        assert radio_path_valid(call("step", hz, delta))
    hz = call("next", hz)
assert hz == 300000000
assert len(seen) == 1099, len(seen)
assert {300000000, 348000000, 387000000, 464000000, 779000000, 928000000} <= seen
for start in [300000000, 433920000, 868350000]:
    for delta in [-25000, 25000]:
        hz, visited = start, set()
        while hz not in visited:
            assert valid(hz) and radio_path_valid(hz), hz
            visited.add(hz)
            hz = call("step", hz, delta)
for hz in [300000000, 300000000, 315000000, 348000000, 387000000,
           433920000, 464000000, 779000000, 868350000, 915000000, 928000000]:
    for direction in [-1, 1]:
        assert valid(call("quick", hz, direction))
        assert radio_path_valid(call("quick", hz, direction))
for threshold in range(-105, -44, 5):
    assert call("beep", threshold - 1, threshold) == 0
    intervals = [call("beep", rssi, threshold) for rssi in range(threshold, 1)]
    assert intervals[0] == 900 and intervals[-1] == 100
    assert all(a >= b for a, b in zip(intervals, intervals[1:]))
assert call("graph", -127) == 0
assert call("graph", -110) == 0
assert call("graph", -30) == 22
assert call("graph", 0) == 22
for scenario in range(4):
    assert call("raw", scenario) == 0, f"RAW scenario {scenario}"
colors = [call("led", phase) for phase in range(0, 1536, 8)]
assert len(set(colors)) == 192
assert call("led", 0) == call("led", 1536)
for color in colors:
    assert all(0 <= ((color >> shift) & 255) <= 127 for shift in [0, 8, 16])

def api(path):
    with path.open(newline="", encoding="utf-8-sig") as file:
        return {row["name"]: row for row in csv.DictReader(file)
                if row["status"] == "+" and row["entry"] in ("Function", "Variable")}

sdk_api = api(build / "ufbt/current/sdk_headers/f7_sdk/targets/f7/api_symbols.csv")
device_api = api(build / "device-api.csv")
imports = [line.split()[-1] for line in run(
    "arm-none-eabi-nm", "-u", ROOT / "dist/signal_finder.fap").splitlines()]
for name in imports:
    assert name in device_api, f"Missing API 88.15 import: {name}"
    assert sdk_api[name] == device_api[name], f"Changed declaration: {name}"
assert not any("_tx" in name or "write_packet" in name for name in imports)
print(f"PASS: {len(seen)} sweep frequencies, band edges, tuning wrap, quick selection,")
print("      beep monotonicity and graph bounds executed as Cortex-M4 Thumb code.")
print(f"PASS: all {len(imports)} FAP imports exist with identical declarations in API 88.15.")
print("PASS: no transmit or packet-write imports.")
print("PASS: RAW pulse polarity, level merging, capacity guards and duration overflow.")
print("PASS: 192 scanning LED colors, brightness bounds and hue-wheel wrap.")
