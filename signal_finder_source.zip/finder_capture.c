#include "finder_capture.h"
#include "finder_logic.h"
#include <lib/subghz/environment.h>
#include <lib/subghz/receiver.h>
#include <lib/subghz/subghz_protocol_registry.h>
#include <storage/storage.h>
#include <stdio.h>
#include <string.h>

typedef struct {
    bool level;
    uint32_t duration;
} FinderPulse;

struct FinderCapture {
    FuriMessageQueue* pulses;
    SubGhzEnvironment* environment;
    SubGhzReceiver* receiver;
    SubGhzProtocolRegistry* registry;
    const SubGhzProtocol** protocols;
    FuriString* details;
    bool active;
    bool recording;
    bool truncated;
    bool raw_invalid;
    volatile uint32_t dropped;
    uint32_t handled_drops;
    int32_t* raw;
    size_t raw_count;
    char protocol[48];
    char status[48];
};

const char* finder_preset_name(uint8_t modulation) {
    const char* names[] = {
        "FuriHalSubGhzPresetOok650Async",
        "FuriHalSubGhzPreset2FSKDev238Async",
        "FuriHalSubGhzPreset2FSKDev12KAsync"};
    return names[modulation % 3];
}

FuriHalSubGhzPreset finder_preset(uint8_t modulation) {
    const FuriHalSubGhzPreset presets[] = {
        FuriHalSubGhzPresetOok650Async,
        FuriHalSubGhzPreset2FSKDev238Async,
        FuriHalSubGhzPreset2FSKDev12KAsync};
    return presets[modulation % 3];
}

/* Runs in the radio interrupt: enqueue only, never decode or access storage. */
static void pulse_callback(bool level, uint32_t duration, void* context) {
    FinderCapture* capture = context;
    FinderPulse pulse = {.level = level, .duration = duration};
    if(furi_message_queue_put(capture->pulses, &pulse, 0) != FuriStatusOk) {
        capture->dropped++;
    }
}

/* Decoder callbacks run in the app thread, while its display mutex is held. */
static void
    decoded_callback(SubGhzReceiver* receiver, SubGhzProtocolDecoderBase* decoder, void* context) {
    UNUSED(receiver);
    FinderCapture* capture = context;
    snprintf(capture->protocol, sizeof(capture->protocol), "%s", decoder->protocol->name);
    furi_string_reset(capture->details);
    subghz_protocol_decoder_base_get_string(decoder, capture->details);
    if(furi_string_empty(capture->details)) {
        furi_string_set(capture->details, "Decoded frame; no fields supplied by this decoder.");
    }
}

FinderCapture* finder_capture_alloc(void) {
    FinderCapture* capture = malloc(sizeof(FinderCapture));
    memset(capture, 0, sizeof(FinderCapture));
    capture->pulses = furi_message_queue_alloc(1024, sizeof(FinderPulse));
    capture->details = furi_string_alloc();
    snprintf(capture->protocol, sizeof(capture->protocol), "Unknown protocol");
    furi_string_set(
        capture->details, "Waiting for a supported frame. Check frequency and OOK/FSK.");
    return capture;
}

void finder_capture_start(FinderCapture* capture, const SubGhzDevice* radio) {
    if(!capture->receiver) {
        capture->environment = subghz_environment_alloc();
        /* The receiver allocates every registry entry before applying its filter.
         * Omit RAW/BinRAW decoders: our own bounded RAW buffer handles recording. */
        size_t available = subghz_protocol_registry_count(&subghz_protocol_registry);
        capture->protocols = malloc(available * sizeof(SubGhzProtocol*));
        size_t count = 0;
        for(size_t i = 0; i < available; i++) {
            const SubGhzProtocol* protocol =
                subghz_protocol_registry_get_by_index(&subghz_protocol_registry, i);
            if(protocol->decoder && (protocol->flag & SubGhzProtocolFlag_Decodable) &&
               protocol->type != SubGhzProtocolTypeRAW &&
               protocol->type != SubGhzProtocolTypeBinRAW) {
                capture->protocols[count++] = protocol;
            }
        }
        SubGhzProtocolRegistry registry = {.items = capture->protocols, .size = count};
        capture->registry = malloc(sizeof(registry));
        memcpy(capture->registry, &registry, sizeof(registry));
        subghz_environment_set_protocol_registry(capture->environment, capture->registry);
        subghz_environment_set_came_atomo_rainbow_table_file_name(
            capture->environment, SUBGHZ_CAME_ATOMO_DIR_NAME);
        subghz_environment_set_alutech_at_4n_rainbow_table_file_name(
            capture->environment, SUBGHZ_ALUTECH_AT_4N_DIR_NAME);
        subghz_environment_set_nice_flor_s_rainbow_table_file_name(
            capture->environment, SUBGHZ_NICE_FLOR_S_DIR_NAME);
        capture->receiver = subghz_receiver_alloc_init(capture->environment);
        subghz_receiver_set_filter(capture->receiver, SubGhzProtocolFlag_Decodable);
        subghz_receiver_set_rx_callback(capture->receiver, decoded_callback, capture);
    }
    furi_message_queue_reset(capture->pulses);
    capture->handled_drops = capture->dropped;
    subghz_receiver_reset(capture->receiver);
    subghz_devices_start_async_rx(radio, pulse_callback, capture);
    capture->active = true;
}

void finder_capture_stop(FinderCapture* capture, const SubGhzDevice* radio) {
    if(capture->active) {
        subghz_devices_stop_async_rx(radio);
        capture->active = false;
    }
}

void finder_capture_reset(FinderCapture* capture) {
    if(capture->receiver) subghz_receiver_reset(capture->receiver);
    snprintf(capture->protocol, sizeof(capture->protocol), "Unknown protocol");
    furi_string_set(
        capture->details, "Waiting for a supported frame. Check frequency and OOK/FSK.");
}

void finder_capture_drain(FinderCapture* capture) {
    if(capture->dropped != capture->handled_drops) {
        capture->handled_drops = capture->dropped;
        if(capture->receiver) subghz_receiver_reset(capture->receiver);
        if(capture->recording) capture->raw_invalid = true;
        snprintf(capture->status, sizeof(capture->status), "RX overflow; retry");
    }
    FinderPulse pulse;
    /* Bound each pass so button processing cannot starve under heavy noise. */
    for(size_t i = 0; i < 1024; i++) {
        if(furi_message_queue_get(capture->pulses, &pulse, 0) != FuriStatusOk) break;
        if(capture->recording && !capture->truncated) {
            if(!finder_raw_append(
                   capture->raw,
                   &capture->raw_count,
                   FINDER_RAW_LIMIT,
                   pulse.level,
                   pulse.duration)) {
                capture->truncated = true;
            }
        } else if(!capture->recording && capture->receiver) {
            subghz_receiver_decode(capture->receiver, pulse.level, pulse.duration);
        }
    }
}

bool finder_capture_record_begin(FinderCapture* capture) {
    capture->raw = malloc(FINDER_RAW_LIMIT * sizeof(int32_t));
    if(!capture->raw) {
        snprintf(capture->status, sizeof(capture->status), "No memory for RAW");
        return false;
    }
    capture->raw_count = 0;
    capture->truncated = capture->raw_invalid = false;
    capture->handled_drops = capture->dropped;
    capture->recording = true;
    capture->status[0] = '\0';
    return true;
}

void finder_capture_record_cancel(FinderCapture* capture) {
    free(capture->raw);
    capture->raw = NULL;
    capture->recording = false;
    snprintf(capture->status, sizeof(capture->status), "RAW cancelled");
}

void finder_capture_record_finish(FinderCapture* capture, uint32_t frequency, uint8_t modulation) {
    capture->recording = false;
    if(capture->raw_count == FINDER_RAW_LIMIT) capture->truncated = true;
    if(capture->raw_invalid || !capture->raw_count) {
        snprintf(
            capture->status,
            sizeof(capture->status),
            capture->raw_invalid ? "Overflow: RAW not saved" : "No pulses: not saved");
        free(capture->raw);
        capture->raw = NULL;
        return;
    }
    Storage* storage = furi_record_open(RECORD_STORAGE);
    const char* folder = EXT_PATH("subghz/signal_finder");
    storage_common_mkdir(storage, EXT_PATH("subghz"));
    storage_common_mkdir(storage, folder);
    FlipperFormat* file = flipper_format_file_alloc(storage);
    char path[96];
    char filename[32];
    uint32_t timestamp = furi_hal_rtc_get_timestamp();
    bool opened = false;
    for(unsigned i = 0; i < 100; i++) {
        snprintf(filename, sizeof(filename), "SF_%08lx_%02u.sub", (unsigned long)timestamp, i);
        snprintf(path, sizeof(path), "%s/%s", folder, filename);
        if(storage_common_exists(storage, path)) continue;
        opened = flipper_format_file_open_new(file, path);
        break;
    }
    bool ok =
        opened &&
        flipper_format_write_header_cstr(file, SUBGHZ_RAW_FILE_TYPE, SUBGHZ_RAW_FILE_VERSION) &&
        flipper_format_write_uint32(file, "Frequency", &frequency, 1) &&
        flipper_format_write_string_cstr(file, "Preset", finder_preset_name(modulation)) &&
        flipper_format_write_string_cstr(file, "Protocol", "RAW");
    for(size_t i = 0; ok && i < capture->raw_count; i += 64) {
        size_t count = capture->raw_count - i;
        if(count > 64) count = 64;
        ok = flipper_format_write_int32(file, "RAW_Data", capture->raw + i, count);
    }
    if(ok && capture->truncated) {
        ok = flipper_format_write_comment_cstr(file, "Stopped at capture buffer limit");
    }
    /* close flushes storage before reporting success */
    bool closed = flipper_format_file_close(file);
    ok = ok && closed;
    flipper_format_free(file);
    if(!ok && opened) storage_common_remove(storage, path);
    snprintf(
        capture->status, sizeof(capture->status), ok ? "Saved %s" : "SD save failed", filename);
    furi_record_close(RECORD_STORAGE);
    free(capture->raw);
    capture->raw = NULL;
}

void finder_capture_free(FinderCapture* capture) {
    furi_check(!capture->active);
    if(capture->raw) free(capture->raw);
    if(capture->receiver) subghz_receiver_free(capture->receiver);
    if(capture->environment) subghz_environment_free(capture->environment);
    free(capture->registry);
    free(capture->protocols);
    furi_string_free(capture->details);
    furi_message_queue_free(capture->pulses);
    free(capture);
}

bool finder_capture_recording(const FinderCapture* capture) {
    return capture->recording;
}
bool finder_capture_record_full(const FinderCapture* capture) {
    return capture->truncated || capture->raw_count == FINDER_RAW_LIMIT || capture->raw_invalid;
}
size_t finder_capture_raw_count(const FinderCapture* capture) {
    return capture->raw_count;
}
const char* finder_capture_protocol(const FinderCapture* capture) {
    return capture->protocol;
}
const char* finder_capture_details(const FinderCapture* capture) {
    return furi_string_get_cstr(capture->details);
}
const char* finder_capture_status(const FinderCapture* capture) {
    return capture->status;
}
