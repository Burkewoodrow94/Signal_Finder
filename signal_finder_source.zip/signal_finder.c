#include <furi.h>
#include <furi_hal.h>
#include <gui/gui.h>
#include <input/input.h>
#include <notification/notification_messages.h>
#include <lib/subghz/devices/devices.h>
#include <stdio.h>
#include <string.h>
#include "finder_logic.h"
#include "finder_capture.h"

#define HISTORY  120
#define START_HZ 300000000

typedef struct {
    FuriMutex* mutex;
    FuriMessageQueue* events;
    const SubGhzDevice* radio;
    bool locked;
    bool muted;
    bool has_candidate;
    bool speaker;
    uint32_t frequency;
    uint32_t best_frequency;
    int rssi;
    int best_rssi;
    int threshold;
    uint8_t history[HISTORY];
    uint8_t history_pos;
    FinderCapture* capture;
    uint8_t modulation;
    bool details;
    uint16_t detail_scroll;
    uint32_t record_start;
    uint32_t graph_tick;
    bool preset_loaded;
    uint8_t loaded_modulation;
    NotificationApp* notification;
    bool scan_led;
    uint16_t led_phase;
    uint32_t led_tick;
} Finder;

static void scan_led_update(Finder* app, bool scanning) {
    if(!scanning) {
        if(app->scan_led) {
            notification_message_block(app->notification, &sequence_reset_rgb);
            app->scan_led = false;
        }
        return;
    }
    uint32_t now = furi_get_tick();
    if(app->scan_led && now - app->led_tick < furi_ms_to_ticks(60)) return;
    uint32_t rgb = finder_led_rgb(app->led_phase);
    NotificationMessage red = {
        .type = NotificationMessageTypeLedRed, .data.led.value = (rgb >> 16) & 0xff};
    NotificationMessage green = {
        .type = NotificationMessageTypeLedGreen, .data.led.value = (rgb >> 8) & 0xff};
    NotificationMessage blue = {
        .type = NotificationMessageTypeLedBlue, .data.led.value = rgb & 0xff};
    const NotificationSequence color = {&red, &green, &blue, &message_do_not_reset, NULL};
    /* Local messages remain alive until this call completes; the sequence has no delay. */
    notification_message_block(app->notification, &color);
    app->scan_led = true;
    app->led_tick = now;
    app->led_phase = (app->led_phase + 8) % 1536;
}

static const char* modulation_text(uint8_t modulation) {
    const char* names[] = {"OOK", "FSK2", "FSK12"};
    return names[modulation % 3];
}

static void draw_details(Canvas* canvas, Finder* app) {
    const char* cursor = finder_capture_details(app->capture);
    unsigned line = 0;
    unsigned drawn = 0;
    char text[25];
    while(*cursor && drawn < 4) {
        unsigned length = 0;
        while(*cursor && *cursor != '\n' && length < 24) {
            if(*cursor != '\r') text[length++] = *cursor;
            cursor++;
        }
        if(*cursor == '\n') cursor++;
        text[length] = '\0';
        if(line++ >= app->detail_scroll) {
            canvas_draw_str(canvas, 2, 29 + drawn * 9, text);
            drawn++;
        }
    }
    if(!drawn && app->detail_scroll) app->detail_scroll--;
    canvas_draw_str(canvas, 2, 63, "^v:scroll OK/Back:graph");
}

static void frequency_text(char* text, size_t size, uint32_t hz) {
    snprintf(
        text,
        size,
        "%lu.%03lu",
        (unsigned long)(hz / 1000000),
        (unsigned long)((hz % 1000000) / 1000));
}

static void draw(Canvas* canvas, void* context) {
    Finder* app = context;
    furi_mutex_acquire(app->mutex, FuriWaitForever);
    char text[40];
    char frequency[16];
    canvas_set_font(canvas, FontSecondary);
    snprintf(
        text,
        sizeof(text),
        "%s %s %s T:%d",
        finder_capture_recording(app->capture) ? "RAW" :
        app->locked                            ? "LOCK" :
                                                 "SWEEP",
        modulation_text(app->modulation),
        app->muted ? "M" : "B",
        app->threshold);
    canvas_draw_str(canvas, 2, 9, text);
    frequency_text(frequency, sizeof(frequency), app->frequency);
    snprintf(text, sizeof(text), "%s MHz  %d dBm", frequency, app->rssi);
    canvas_draw_str(canvas, 2, 20, text);
    if(app->details && !finder_capture_recording(app->capture)) {
        draw_details(canvas, app);
    } else if(!app->locked) {
        if(app->has_candidate) {
            frequency_text(frequency, sizeof(frequency), app->best_frequency);
            snprintf(text, sizeof(text), "Peak %s  %d dBm", frequency, app->best_rssi);
        } else {
            snprintf(text, sizeof(text), "Searching above %d dBm", app->threshold);
        }
        canvas_draw_str(canvas, 2, 31, text);
        uint32_t total = (app->frequency <= 348000000) ? app->frequency - START_HZ :
                         (app->frequency <= 464000000) ? 48000000 + app->frequency - 387000000 :
                                                         125000000 + app->frequency - 779000000;
        canvas_draw_frame(canvas, 3, 36, 122, 9);
        canvas_draw_box(canvas, 4, 37, (uint64_t)total * 120 / 274000000, 7);
        canvas_draw_str(canvas, 2, 54, "OK:lock <>:433.920");
    } else {
        if(finder_capture_recording(app->capture)) {
            snprintf(
                text,
                sizeof(text),
                "RAW %u/%u  Hold ^:save",
                (unsigned)finder_capture_raw_count(app->capture),
                FINDER_RAW_LIMIT);
        } else {
            snprintf(text, sizeof(text), "%.24s", finder_capture_protocol(app->capture));
        }
        canvas_draw_str(canvas, 2, 30, text);
        canvas_draw_frame(canvas, 3, 33, 122, 17);
        for(uint8_t x = 0; x < HISTORY; x++) {
            uint8_t height = app->history[(app->history_pos + x) % HISTORY] * 14 / 22;
            if(height) canvas_draw_line(canvas, 4 + x, 48, 4 + x, 48 - height);
        }
        const char* status = finder_capture_status(app->capture);
        snprintf(text, sizeof(text), "%.25s", status[0] ? status : "OK:data Hold Back:sweep");
        canvas_draw_str(canvas, 2, 61, text);
    }
    if(!app->locked) canvas_draw_str(canvas, 2, 63, "Hold ^:RAW v:mode OK:mute");
    furi_mutex_release(app->mutex);
}

static void input(InputEvent* event, void* context) {
    Finder* app = context;
    /* Never block the GUI service if the application is tuning. */
    furi_message_queue_put(app->events, event, 0);
}

static void tune(Finder* app) {
    finder_capture_stop(app->capture, app->radio);
    subghz_devices_idle(app->radio);
    /* Loading a preset resets the CC1101, so do it BEFORE tuning frequency/path. */
    if(!app->preset_loaded || app->loaded_modulation != app->modulation) {
        subghz_devices_load_preset(app->radio, finder_preset(app->modulation), NULL);
        app->loaded_modulation = app->modulation;
        app->preset_loaded = true;
    }
    furi_check(subghz_devices_is_frequency_valid(app->radio, app->frequency));
    subghz_devices_set_frequency(app->radio, app->frequency);
    subghz_devices_flush_rx(app->radio);
    finder_capture_reset(app->capture);
    if(app->locked) {
        finder_capture_start(app->capture, app->radio);
    } else {
        subghz_devices_set_rx(app->radio);
    }
    /* Allow synthesizer, AGC and RSSI to settle after each hop. */
    furi_delay_ms(8);
}

int32_t signal_finder_app(void* argument) {
    UNUSED(argument);
    Finder* app = malloc(sizeof(Finder));
    memset(app, 0, sizeof(Finder));
    app->mutex = furi_mutex_alloc(FuriMutexTypeNormal);
    app->events = furi_message_queue_alloc(8, sizeof(InputEvent));
    app->capture = finder_capture_alloc();
    app->notification = furi_record_open(RECORD_NOTIFICATION);
    app->frequency = START_HZ;
    app->threshold = -85;
    app->rssi = -110;
    app->best_rssi = -127;
    subghz_devices_init();
    app->radio = subghz_devices_get_by_name("cc1101_int");
    furi_check(app->radio);
    subghz_devices_begin(app->radio);
    subghz_devices_reset(app->radio);
    tune(app);
    app->speaker = furi_hal_speaker_acquire(0);
    app->muted = !app->speaker;
    Gui* gui = furi_record_open(RECORD_GUI);
    ViewPort* viewport = view_port_alloc();
    view_port_draw_callback_set(viewport, draw, app);
    view_port_input_callback_set(viewport, input, app);
    gui_add_view_port(gui, viewport, GuiLayerFullscreen);

    bool running = true;
    bool sounding = false;
    uint32_t last_beep = 0;
    uint32_t beep_start = 0;
    uint32_t last_draw = 0;
    int sweep_peak = -127;
    uint32_t sweep_frequency = START_HZ;
    while(running) {
        InputEvent event;
        furi_mutex_acquire(app->mutex, FuriWaitForever);
        bool retune = false;
        while(furi_message_queue_get(app->events, &event, 0) == FuriStatusOk) {
            if(event.key == InputKeyUp && event.type == InputTypeLong) {
                if(finder_capture_recording(app->capture)) {
                    finder_capture_stop(app->capture, app->radio);
                    finder_capture_drain(app->capture);
                    finder_capture_record_finish(app->capture, app->frequency, app->modulation);
                    retune = true;
                } else {
                    if(!app->locked) {
                        app->locked = true;
                        app->frequency = app->has_candidate ? app->best_frequency : 433920000;
                    }
                    app->details = false;
                    /* Restart capture to exclude pulses received before pressing Record. */
                    tune(app);
                    if(finder_capture_record_begin(app->capture)) {
                        app->record_start = furi_get_tick();
                    }
                    retune = false;
                }
            } else if(finder_capture_recording(app->capture)) {
                if(event.key == InputKeyBack && event.type == InputTypeShort) {
                    finder_capture_stop(app->capture, app->radio);
                    finder_capture_record_cancel(app->capture);
                    retune = true;
                }
                /* Freeze frequency, modulation and mode for the entire RAW capture. */
            } else if(event.key == InputKeyBack && event.type == InputTypeLong && app->locked) {
                app->locked = false;
                app->details = false;
                app->frequency = START_HZ;
                app->has_candidate = false;
                app->best_rssi = sweep_peak = -127;
                retune = true;
            } else if(event.key == InputKeyBack && event.type == InputTypeShort) {
                if(app->details)
                    app->details = false;
                else
                    running = false;
            } else if(event.key == InputKeyDown && event.type == InputTypeLong) {
                app->modulation = (app->modulation + 1) % 3;
                app->details = false;
                app->has_candidate = false;
                app->best_rssi = sweep_peak = -127;
                if(!app->locked) app->frequency = START_HZ;
                retune = true;
            } else if(event.key == InputKeyOk && event.type == InputTypeLong) {
                if(app->speaker) app->muted = !app->muted;
            } else if(
                (event.key == InputKeyLeft || event.key == InputKeyRight) &&
                event.type == InputTypeLong) {
                app->locked = true;
                app->details = false;
                app->frequency =
                    finder_quick_frequency(app->frequency, event.key == InputKeyRight ? 1 : -1);
                memset(app->history, 0, sizeof(app->history));
                app->history_pos = 0;
                retune = true;
            } else if(event.key == InputKeyOk && event.type == InputTypeShort) {
                if(app->locked) {
                    app->details = !app->details;
                    app->detail_scroll = 0;
                } else if(app->has_candidate) {
                    app->locked = true;
                    app->frequency = app->best_frequency;
                    memset(app->history, 0, sizeof(app->history));
                    app->history_pos = 0;
                    retune = true;
                }
            } else if(event.type == InputTypeShort || event.type == InputTypeRepeat) {
                if(app->details) {
                    if(event.key == InputKeyUp && app->detail_scroll) app->detail_scroll--;
                    if(event.key == InputKeyDown && app->detail_scroll < 200) app->detail_scroll++;
                    continue;
                }
                if(event.key == InputKeyUp && app->threshold < -45) app->threshold += 5;
                if(event.key == InputKeyDown && app->threshold > -105) app->threshold -= 5;
                if(!app->locked) app->has_candidate = app->best_rssi >= app->threshold;
                if(event.key == InputKeyLeft || event.key == InputKeyRight) {
                    if(!app->locked) {
                        app->locked = true;
                        app->frequency = 433920000;
                    } else {
                        app->frequency = finder_step_frequency(
                            app->frequency, event.key == InputKeyRight ? 25000 : -25000);
                    }
                    memset(app->history, 0, sizeof(app->history));
                    app->history_pos = 0;
                    retune = true;
                }
            }
        }
        if(!running) {
            furi_mutex_release(app->mutex);
            break;
        }
        if(retune) tune(app);
        finder_capture_drain(app->capture);
        if(finder_capture_recording(app->capture) &&
           (finder_capture_record_full(app->capture) ||
            furi_get_tick() - app->record_start >= furi_ms_to_ticks(10000))) {
            finder_capture_stop(app->capture, app->radio);
            finder_capture_drain(app->capture);
            finder_capture_record_finish(app->capture, app->frequency, app->modulation);
            tune(app);
        }
        app->rssi = (int)subghz_devices_get_rssi(app->radio);
        if(app->locked) {
            if(furi_get_tick() - app->graph_tick >= furi_ms_to_ticks(40)) {
                app->history[app->history_pos] = finder_graph_height(app->rssi);
                app->history_pos = (app->history_pos + 1) % HISTORY;
                app->graph_tick = furi_get_tick();
            }
        } else {
            if(app->rssi > sweep_peak) {
                sweep_peak = app->rssi;
                sweep_frequency = app->frequency;
            }
            if(sweep_peak >= app->threshold &&
               (!app->has_candidate || sweep_peak > app->best_rssi)) {
                app->has_candidate = true;
                app->best_rssi = sweep_peak;
                app->best_frequency = sweep_frequency;
            }
        }
        uint32_t now = furi_get_tick();
        uint32_t interval = finder_beep_interval(app->rssi, app->threshold);
        bool audible = app->speaker && !app->muted && interval;
        if(sounding && (!audible || now - beep_start >= furi_ms_to_ticks(25))) {
            furi_hal_speaker_stop();
            sounding = false;
        }
        if(audible && !sounding && now - last_beep >= furi_ms_to_ticks(interval)) {
            furi_hal_speaker_start(1800.0f, 0.25f);
            last_beep = beep_start = now;
            sounding = true;
        }
        bool locked = app->locked;
        furi_mutex_release(app->mutex);
        scan_led_update(app, !locked);
        if(now - last_draw >= furi_ms_to_ticks(100)) {
            view_port_update(viewport);
            last_draw = now;
        }
        if(locked) {
            furi_delay_ms(5);
        } else {
            furi_mutex_acquire(app->mutex, FuriWaitForever);
            app->frequency = finder_next_frequency(app->frequency);
            if(app->frequency == START_HZ) {
                /* Replace old peaks each sweep so vanished signals do not persist. */
                app->has_candidate = sweep_peak >= app->threshold;
                app->best_rssi = sweep_peak;
                app->best_frequency = sweep_frequency;
                sweep_peak = -127;
            }
            tune(app);
            furi_mutex_release(app->mutex);
        }
    }
    view_port_enabled_set(viewport, false);
    gui_remove_view_port(gui, viewport);
    view_port_free(viewport);
    furi_record_close(RECORD_GUI);
    scan_led_update(app, false);
    furi_record_close(RECORD_NOTIFICATION);
    if(app->speaker) {
        furi_hal_speaker_stop();
        furi_hal_speaker_release();
    }
    finder_capture_stop(app->capture, app->radio);
    finder_capture_free(app->capture);
    subghz_devices_idle(app->radio);
    subghz_devices_sleep(app->radio);
    subghz_devices_end(app->radio);
    subghz_devices_deinit();
    furi_message_queue_free(app->events);
    furi_mutex_free(app->mutex);
    free(app);
    return 0;
}
