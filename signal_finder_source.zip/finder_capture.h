#pragma once
#include <furi.h>
#include <lib/subghz/devices/devices.h>

#define FINDER_RAW_LIMIT 4096

typedef struct FinderCapture FinderCapture;

FinderCapture* finder_capture_alloc(void);
void finder_capture_free(FinderCapture* capture);
void finder_capture_start(FinderCapture* capture, const SubGhzDevice* radio);
void finder_capture_stop(FinderCapture* capture, const SubGhzDevice* radio);
void finder_capture_drain(FinderCapture* capture);
void finder_capture_reset(FinderCapture* capture);
bool finder_capture_record_begin(FinderCapture* capture);
void finder_capture_record_finish(FinderCapture* capture, uint32_t frequency, uint8_t modulation);
void finder_capture_record_cancel(FinderCapture* capture);
bool finder_capture_recording(const FinderCapture* capture);
bool finder_capture_record_full(const FinderCapture* capture);
size_t finder_capture_raw_count(const FinderCapture* capture);
const char* finder_capture_protocol(const FinderCapture* capture);
const char* finder_capture_details(const FinderCapture* capture);
const char* finder_capture_status(const FinderCapture* capture);
const char* finder_preset_name(uint8_t modulation);
FuriHalSubGhzPreset finder_preset(uint8_t modulation);
